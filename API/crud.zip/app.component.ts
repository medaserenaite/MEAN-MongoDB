import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  constructor(private _httpService: HttpService) { } //( _ <-- this belongs only to this class)
  taskForm:object;
  ngOnInit(){
    this.getTasks();
    this.taskForm = { name:"", description:""}
  }
  tasks = [];
  editing= {
    name: '',
    description: ''
  }
  editing: object;
  detail:object;
  getTasks() {
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log(data);  
      this.tasks = data['tasks'];
      // let tasks = data['tasks'];
      // for(let thing in tasks) {
      //     this.tasks.push(tasks[thing]);
      // }
      console.log(this.tasks)
  })
}
show(task){
  this.detail = task;
}
  create(){
    console.log(this.taskForm)
    console.log()
    let observable = this._httpService.create(this.taskForm);
    observable.subscribe((data:any) => {
      //console.log(data.task)
      this.taskForm ={ name: "", description: "" }
      this.getTasks()
    })
  }
  edit(task){
    // this.editing.name = task.name
    // this.editing.description = task.description
    this.editing = task
  }
  update(){
    console.log(this.editing)
    let observable = this._httpService.update(this.editing);
    observable.subscribe((data) => {
      //console.log(data)
      this.editing  =null;
      this.getTasks()
      // console.log(this.editing)
    })
  }

  
  delete(task){
    let observable = this._httpService.delete(task);
    observable.subscribe((data) => {
      this.getTasks();
    })
  }

}