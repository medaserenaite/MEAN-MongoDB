import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {//implements OnInit
  title = 'public';
  tasks = [];
  //dependency injection
  constructor(private _httpService: HttpService) { } //( _ <-- this belongs only to this class)

  getTasks() {
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log(data);  
      let tasks = data['data'];
      for(let thing in tasks) {
          this.tasks.push(tasks[thing]);
      }
      console.log(this.tasks)
  })
}
  showInfo(task_id){
    console.log("hey");
  }
  
}