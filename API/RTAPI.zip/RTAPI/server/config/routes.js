const task = require('../controllers/tasks.js');

module.exports = function(app) {
  app.get('/tasks', function(req, res) {
    task.showAll(req, res);
  })
  app.get('/new/:name/', (req, res) => {
    task.add(req, res);
  })
  app.get('/remove/:name/', (req, res) => {
    task.remove(req, res);
  })
  app.get('/:id/', (req, res) => {
    task.show(req, res);
  })
}